# BrowserCleaner
This is a simple chrome extension made to clear browser data.
